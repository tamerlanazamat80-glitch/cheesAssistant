import SwiftUI

@main
struct ChessAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "chessboard")
                .font(.system(size: 48))
            Text("Chess Assistant")
                .font(.largeTitle.bold())
            Text("Учебный редактор позиций для Safari")
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Text("После установки включи расширение в Настройки → Приложения → Safari → Расширения.")
                .font(.footnote)
                .multilineTextAlignment(.center)
                .padding(.top, 8)
        }
        .padding(24)
    }
}
