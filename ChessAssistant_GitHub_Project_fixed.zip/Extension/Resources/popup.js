const initialFen="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
const glyphs={K:"♔",Q:"♕",R:"♖",B:"♗",N:"♘",P:"♙",k:"♚",q:"♛",r:"♜",b:"♝",n:"♞",p:"♟"};
let board=[],selected=null;
function parseFen(fen){const rows=fen.trim().split(/\s+/)[0].split("/");if(rows.length!==8)throw Error("FEN должен содержать 8 рядов.");const out=[];for(const row of rows){const cells=[];for(const ch of row){if(/[1-8]/.test(ch)){for(let i=0;i<+ch;i++)cells.push("");}else if(/[prnbqkPRNBQK]/.test(ch))cells.push(ch);else throw Error("Некорректный символ FEN.");}if(cells.length!==8)throw Error("В каждом ряду должно быть 8 клеток.");out.push(...cells);}return out;}
function toFen(){const rows=[];for(let r=0;r<8;r++){let row="",empty=0;for(let c=0;c<8;c++){const p=board[r*8+c];if(!p)empty++;else{if(empty){row+=empty;empty=0;}row+=p;}}if(empty)row+=empty;rows.push(row);}return rows.join("/")+" w - - 0 1";}
function render(){const el=document.getElementById("board");el.innerHTML="";board.forEach((piece,i)=>{const r=Math.floor(i/8),c=i%8,sq=document.createElement("button");sq.type="button";sq.className="square "+((r+c)%2?"dark":"light")+(selected===i?" selected":"");sq.textContent=piece?(glyphs[piece]||piece):"";sq.addEventListener("click",()=>tap(i));el.appendChild(sq);});document.getElementById("fen").value=toFen();}
function tap(i){if(selected===null){if(board[i])selected=i;}else if(selected===i)selected=null;else{board[i]=board[selected];board[selected]="";selected=null;}render();}
function msg(t){document.getElementById("message").textContent=t;}
document.getElementById("reset").onclick=()=>{board=parseFen(initialFen);selected=null;render();msg("Начальная позиция загружена.");};
document.getElementById("applyFen").onclick=()=>{try{board=parseFen(document.getElementById("fen").value);selected=null;render();msg("Позиция загружена.");}catch(e){msg(e.message);}};
document.getElementById("copyFen").onclick=async()=>{try{await navigator.clipboard.writeText(toFen());msg("FEN скопирован.");}catch{msg("Выдели FEN вручную.");}};
document.getElementById("theme").onchange=e=>document.body.classList.toggle("light",e.target.value==="light");
document.getElementById("highlights").onchange=e=>document.querySelectorAll(".square").forEach(s=>s.style.outlineColor=e.target.checked?"var(--accent)":"transparent");
document.getElementById("boardSize").oninput=e=>document.getElementById("board").style.width=e.target.value+"px";
board=parseFen(initialFen);render();
