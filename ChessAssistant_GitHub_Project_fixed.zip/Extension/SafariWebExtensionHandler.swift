import SafariServices
import os.log

class SafariWebExtensionHandler: NSObject, NSExtensionRequestHandling {
    func beginRequest(with context: NSExtensionContext) {
        let item = NSExtensionItem()
        item.userInfo = [ SFExtensionMessageKey: ["message": "Chess Assistant study extension ready"] ]
        context.completeRequest(returningItems: [item], completionHandler: nil)
    }
}
